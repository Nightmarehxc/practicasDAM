class Mes
{
    private float dia1;
    private float dia30;


    public float getDia1() {
        return dia1;
    }

    public void setDia1(float dia1) {
        this.dia1 = dia1;
    }

    public float getDia30() {
        return dia30;
    }

    public void setDia30(float dia30) {
        this.dia30 = dia30;
    }
}
