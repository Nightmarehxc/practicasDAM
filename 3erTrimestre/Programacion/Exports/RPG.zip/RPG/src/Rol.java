public interface Rol
{

    static int CalcularPoder()
    {
        int poder =0;
        return poder;
    }
}
