select * from personas
order by grupo,curso desc;