alter  table ALUMNOS
ADD edad int(2);