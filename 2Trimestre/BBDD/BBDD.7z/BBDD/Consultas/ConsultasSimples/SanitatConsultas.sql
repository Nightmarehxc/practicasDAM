USE sanitat;

/*
	1. Muestre los hospitales existentes (número, nombre y teléfono).
*/
SELECT ` HOSPITAL_COD `,` NOM `,` TELEFON ` FROM ` hospital `; 
/*
2. Muestre los hospitales existentes (número, nombre y teléfono) que tengan una letra A en la segunda posición del nombre.
*/
SELECT HOSPITAL_COD,TELEFON,SUBSTR(NOM, 2,1) AS str FROM hospital
WHERE str LIKE '%a%'
LIMIT 1; 
/*
. Muestre los trabajadores (código hospital, código sala, número empleado y apellido) existentes.
*/