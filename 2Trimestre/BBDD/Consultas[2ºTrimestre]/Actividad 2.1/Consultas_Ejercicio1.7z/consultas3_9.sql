select usuario from tblUsuarios
where activo = 0;