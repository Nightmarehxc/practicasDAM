select email from tblUsuarios
where email not like '%yahoo%';