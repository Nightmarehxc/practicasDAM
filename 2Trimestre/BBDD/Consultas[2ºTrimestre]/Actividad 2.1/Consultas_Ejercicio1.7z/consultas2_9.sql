select marca from tblUsuarios
GROUP BY  marca DESC;