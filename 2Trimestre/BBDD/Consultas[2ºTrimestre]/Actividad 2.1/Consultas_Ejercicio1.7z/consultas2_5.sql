select usuario, telefono from tblUsuarios
where compa�ia like 'iusacell' or 'axel';