select marca from tblusuarios
group by marca ;