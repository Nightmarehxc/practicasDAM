select telefono from tblUsuarios
where saldo =0;