select usuario from tblUsuarios
where nivel  in (1,3);