SELECT nombre, telefono FROM tblUsuarios 
WHERE marca='LG'OR'SAMSUNG'OR'MOTOROLA';