select usuario, telefono from tblusuarios
where compa�ia like 'IUSACELL' or 'TELCEL';