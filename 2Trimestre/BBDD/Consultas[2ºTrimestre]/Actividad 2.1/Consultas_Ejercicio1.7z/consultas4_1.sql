select  marca , count(usuario)from tblUsuarios
group by marca ASC;