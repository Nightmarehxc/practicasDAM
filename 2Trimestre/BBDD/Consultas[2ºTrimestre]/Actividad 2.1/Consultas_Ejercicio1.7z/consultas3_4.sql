select usuario from tblUsuarios
where nivel = 0;