select usuario,telefono from tblusuarios
where compa�ia like '%iusa%' or '%une%';