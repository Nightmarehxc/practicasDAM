select usuario from tblusuarios
where saldo or activo like '0';