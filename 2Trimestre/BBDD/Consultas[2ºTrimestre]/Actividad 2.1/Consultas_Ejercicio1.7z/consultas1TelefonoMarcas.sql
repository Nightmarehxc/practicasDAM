SELECT nombre, telefono FROM tblUsuarios 
WHERE marca='NOKIA'OR'BLACKBERRY'OR'SONY';