select usuario, telefono from tblUsuarios
where compa�ia not like 'iusacell' or 'axel';