select usuario,telefono from tblusuarios
where marca not like  'motorola' or '%okia%';