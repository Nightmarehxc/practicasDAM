select avg(saldo) from tblUsuarios
where marca = 'Nokia';