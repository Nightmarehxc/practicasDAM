select usuario from tblusuarios
where email like '%hotmail%';