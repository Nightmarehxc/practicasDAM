select nombre, telefono from tblUsuarios
where marca not LIKE 'TELCEL';