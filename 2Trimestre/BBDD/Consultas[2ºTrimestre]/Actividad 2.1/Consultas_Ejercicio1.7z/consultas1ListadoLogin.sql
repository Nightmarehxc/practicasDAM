select usuario,  nivel from tblUsuarios
where nivel in (1,2,3);
