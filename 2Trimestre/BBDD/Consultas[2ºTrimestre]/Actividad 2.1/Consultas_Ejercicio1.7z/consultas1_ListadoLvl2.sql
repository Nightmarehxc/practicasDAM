select usuario,  nivel from tblUsuarios
where nivel = 2;
