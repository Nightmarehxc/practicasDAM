select nombre, telefono from tblUsuarios
where marca NOT LIKE 'LG' or 'SAMSUNG';