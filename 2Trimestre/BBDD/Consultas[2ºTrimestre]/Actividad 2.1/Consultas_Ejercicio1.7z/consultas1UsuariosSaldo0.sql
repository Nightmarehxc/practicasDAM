select count(usuario) from tblUsuarios
where saldo <= 0;