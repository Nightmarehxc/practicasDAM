select nombre, telefono from tblUsuarios
where marca  not like  ('BLACKBERRY');