SELECT COUNT(usuario),compa�ia FROM tblUsuarios
GROUP BY compa�ia asc;