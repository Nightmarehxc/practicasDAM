select usuario , saldo from tblUsuarios
where saldo <= 300;