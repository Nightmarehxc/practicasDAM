select sum(saldo) from tblusuarios
where compa�ia like '%tel%';