select sum(saldo) from tblUsuarios
where  compa�ia = 'NEXTEL';
