select usuario,EMAIL  from tblUsuarios
where email LIKE  '%gmail.com';
