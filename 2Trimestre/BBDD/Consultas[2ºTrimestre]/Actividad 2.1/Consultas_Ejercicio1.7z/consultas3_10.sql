select usuario,min(saldo) from tblUsuarios
where sexo = 'h';