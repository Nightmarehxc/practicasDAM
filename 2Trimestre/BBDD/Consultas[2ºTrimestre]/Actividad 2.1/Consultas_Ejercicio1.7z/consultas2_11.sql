select usuario,nivel from tblUsuarios
where nivel in (0 , 2);