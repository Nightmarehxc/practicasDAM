select compa�ia from tblUsuarios
group by compa�ia ASC;