select usuario from tblUsuarios;
