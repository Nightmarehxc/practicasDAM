select usuario, telefono from tblUsuarios
where marca like 'IUSACELL';