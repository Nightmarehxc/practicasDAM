select  sexo,count(idx) from tblUsuarios
group by sexo;
