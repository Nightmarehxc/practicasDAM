select max(saldo) from tblUsuarios
where sexo = "m";