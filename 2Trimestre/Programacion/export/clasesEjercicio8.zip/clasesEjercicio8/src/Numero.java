
import java.util.*;

public class Numero {
    private static int  valor;
    public Numero ()
    {
        int  valor;

    }

    public static int setNum(int a_num) {
        valor = a_num;
        return valor;
    }

    /**
     * 
     */
    public static int getNum()
    {
        return valor;
    }

}