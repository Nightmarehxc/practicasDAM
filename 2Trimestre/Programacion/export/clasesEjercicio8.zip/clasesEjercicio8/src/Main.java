public class Main {

    public static void main(String[] args)
    {
        Test test1 = new Test();
        test1.IntroduceDatos();
        test1.calcularParImpar();

    }
}
