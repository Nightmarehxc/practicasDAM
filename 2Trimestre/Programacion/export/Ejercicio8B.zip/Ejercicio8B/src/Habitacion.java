
import java.util.*;

/**
 * 
 */
public class Habitacion {

    /**
     * Default constructor
     */
    public Habitacion()
    {

    }


}