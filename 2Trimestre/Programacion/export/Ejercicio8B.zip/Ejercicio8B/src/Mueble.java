
import java.util.*;

/**
 * 
 */
public class Mueble {
    public float sizeX;
    public float sizeY;
    public int capacidad;
    /**
     * Default constructor
     */
    public Mueble()
    {

    }



}