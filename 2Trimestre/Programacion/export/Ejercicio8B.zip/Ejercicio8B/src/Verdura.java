
import java.util.*;

/**
 * 
 */
public class Verdura extends Alimento
{

    /**
     * Default constructor
     */
    public Verdura(String a_name,String a_type,float a_peso,float a_optTemp)
    {
        super(a_name,a_type,a_peso,a_optTemp);
        name = a_name;
        tipo = a_type;
        peso = a_peso;
        optTemp = a_optTemp;


    }



}