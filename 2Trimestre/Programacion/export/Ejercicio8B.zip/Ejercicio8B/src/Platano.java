
import java.util.*;

/**
 * 
 */
public class Platano extends Fruta{




    public Platano(String a_name,String a_type,float a_peso,float a_optTemp)
    {
        super(a_name,a_type,a_peso,a_optTemp);
        name = "Platano";
        tipo = "Fruta";
        peso=0.5f;
        optTemp = 9.f;
    }
}