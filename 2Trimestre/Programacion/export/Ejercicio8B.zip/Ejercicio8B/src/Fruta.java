/**
 * 
 */

public class Fruta extends Alimento
{



    public Fruta(String a_name,String a_type,float a_peso,float a_optTemp)
    {
        super(a_name,a_type,a_peso,a_optTemp);
        name = a_name;
        tipo = a_type;
        peso = a_peso;
        optTemp = a_optTemp;

    }




}