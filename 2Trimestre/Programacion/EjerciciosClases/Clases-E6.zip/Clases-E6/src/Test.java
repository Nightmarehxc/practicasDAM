public class Test extends Descarga
{
    public Test()
    {

    }
    Descarga d1 = new Descarga();
    Descarga d2 = new Descarga();
    Descarga d3 = new Descarga();

}
