public class Descarga
{
    private String name;
    private float peso;
    private float vel;
    public Descarga()
    {
        String a_name;
        float peso;
        float vel;
    }

    public String setName(String a_name)
    {
        name = a_name;
        return name;
    }
    public String getName()

    {
        return name;
    }
    public float setPeso(float a_peso)
    {
        peso = a_peso;
        return peso;
    }
    public Float getPeso()
    {
        return peso;
    }
    public float setVel(float a_vel)
    {
        vel = a_vel;
        return vel;
    }
    public float getVel()
    {
        return vel;
    }



}
