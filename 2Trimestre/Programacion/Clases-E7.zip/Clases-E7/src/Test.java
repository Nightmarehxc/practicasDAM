public class Test
{
    public Test(){

        String a_name;
        float peso;
        float vel;

    }

}
