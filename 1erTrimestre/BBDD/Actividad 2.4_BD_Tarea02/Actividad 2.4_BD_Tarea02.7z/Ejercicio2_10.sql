CREATE USER 'dcorral'@'localhost' IDENTIFIED BY 'DB02';
GRANT ALL PRIVILEGES ON pruebas.cursos TO 'dcorral'@'localhost';

