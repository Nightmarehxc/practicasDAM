
revoke update, grant option from dcorral;

