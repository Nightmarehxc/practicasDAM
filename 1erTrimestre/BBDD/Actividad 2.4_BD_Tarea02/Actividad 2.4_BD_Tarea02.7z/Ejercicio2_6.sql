 ALTER TABLe profesores
 change primary key Nombre,Apellido1;
 