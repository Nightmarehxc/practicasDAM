import javax.swing.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        JFrame frame = new JFrame("Calculadora");
        int a,b=0;
        char [] opChar;
        String op;
        Scanner sc = new Scanner(System.in);
        a = sc.nextInt();
        op = sc.nextLine();
        opChar = op.toCharArray();
        b = sc.nextInt();


    }
}
